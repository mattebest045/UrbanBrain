<?php

$username = "urbanbrain"; // in locale 'root'
$password = '';
$host = "localhost";
$database = "my_urbanbrain"; // in locale 'urbanbrain'

try{
	$pdo = new PDO("mysql:host=$host;dbname=$database;charset=utf8", $username, $password);
	// Set the PDO error made to exception
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e){
	die("ERROR: Could not connect. " . $e->getMessage());
}
?>